export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  isPlaying?: boolean;
}

export interface Language {
  code: string;
  name: string;
  voice: string;
}

export interface DeepSeekModel {
  id: string;
  name: string;
}