import React, { useState, useRef, useEffect } from 'react';
import { Dumbbell, Mic, Send, StopCircle, Volume2, Globe2 } from 'lucide-react';
import { ChatMessage } from './types';
import { MessageList } from './components/MessageList';
import { InputArea } from './components/InputArea';
import { LanguageSelector } from './components/LanguageSelector';
import { ModelSelector } from './components/ModelSelector';
import { LANGUAGES, DEEPSEEK_MODELS } from './config';
import { generateResponse } from './services/deepseek';

function App() {
  const [messages, setMessages] = useState<ChatMessage[]>([{
    role: 'assistant',
    content: "Hello! 👋 I'm your AI Fitness Coach!\n\nI'm here to help you achieve your fitness goals with:\n\n🏋️‍♂️ Personalized workout plans\n🥗 Nutrition advice\n📊 Progress tracking\n💪 Proper form guidance\n🎯 Goal setting\n\nHow can I assist you today?",
    isPlaying: false
  }]);
  const [input, setInput] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(LANGUAGES[0]);
  const [selectedModel, setSelectedModel] = useState(DEEPSEEK_MODELS[0]);
  const mediaRecorder = useRef<MediaRecorder | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognition = useRef<SpeechRecognition | null>(null);
  const speechSynthesis = window.speechSynthesis;
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognition.current = new SpeechRecognition();
      recognition.current.continuous = true;
      recognition.current.interimResults = true;
      recognition.current.lang = selectedLanguage.voice;

      recognition.current.onresult = (event) => {
        const transcript = Array.from(event.results)
          .map(result => result[0])
          .map(result => result.transcript)
          .join('');
        setInput(transcript);
      };
    }
  }, [selectedLanguage]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const newMessage: ChatMessage = {
      role: 'user',
      content: input,
      isPlaying: false
    };

    setMessages(prev => [...prev, newMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await generateResponse(input, selectedModel.id);
      const assistantMessage: ChatMessage = {
        role: 'assistant',
        content: response,
        isPlaying: false
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const startRecording = async () => {
    try {
      if (recognition.current) {
        recognition.current.start();
        setIsRecording(true);
      }
    } catch (error) {
      console.error('Error accessing microphone:', error);
    }
  };

  const stopRecording = () => {
    if (recognition.current) {
      recognition.current.stop();
      setIsRecording(false);
    }
  };

  const playMessage = (message: ChatMessage) => {
    // Stop any currently playing message
    if (utteranceRef.current) {
      speechSynthesis.cancel();
    }

    const utterance = new SpeechSynthesisUtterance(message.content);
    utterance.lang = selectedLanguage.voice;
    utteranceRef.current = utterance;

    utterance.onend = () => {
      setMessages(prev => 
        prev.map(msg => 
          msg === message ? { ...msg, isPlaying: false } : msg
        )
      );
      utteranceRef.current = null;
    };

    setMessages(prev => 
      prev.map(msg => 
        msg === message ? { ...msg, isPlaying: true } : { ...msg, isPlaying: false }
      )
    );

    speechSynthesis.speak(utterance);
  };

  const pauseMessage = (message: ChatMessage) => {
    if (utteranceRef.current) {
      speechSynthesis.cancel();
      utteranceRef.current = null;
      setMessages(prev => 
        prev.map(msg => 
          msg === message ? { ...msg, isPlaying: false } : msg
        )
      );
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      <div className="max-w-4xl mx-auto p-4 h-screen flex flex-col">
        <header className="flex items-center justify-between p-4 bg-white rounded-t-xl shadow-sm">
          <div className="flex items-center gap-3">
            <Dumbbell className="w-8 h-8 text-purple-600" />
            <h1 className="text-2xl font-bold text-gray-800">AI Fitness Coach</h1>
          </div>
          <div className="flex items-center gap-4">
            <ModelSelector
              selectedModel={selectedModel}
              setSelectedModel={setSelectedModel}
            />
            <LanguageSelector
              selectedLanguage={selectedLanguage}
              setSelectedLanguage={setSelectedLanguage}
            />
          </div>
        </header>

        <main className="flex-1 bg-white overflow-hidden flex flex-col">
          <MessageList 
            messages={messages} 
            isLoading={isLoading} 
            messagesEndRef={messagesEndRef}
            onPlayMessage={playMessage}
            onPauseMessage={pauseMessage}
          />
          
          <InputArea
            input={input}
            setInput={setInput}
            handleSend={handleSend}
            isRecording={isRecording}
            startRecording={startRecording}
            stopRecording={stopRecording}
          />
        </main>
      </div>
    </div>
  );
}

export default App;