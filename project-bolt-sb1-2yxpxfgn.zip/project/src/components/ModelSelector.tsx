import React from 'react';
import { DeepSeekModel } from '../types';
import { DEEPSEEK_MODELS } from '../config';

interface ModelSelectorProps {
  selectedModel: DeepSeekModel;
  setSelectedModel: (model: DeepSeekModel) => void;
}

export function ModelSelector({ selectedModel, setSelectedModel }: ModelSelectorProps) {
  return (
    <div className="flex items-center gap-2">
      <select
        value={selectedModel.id}
        onChange={(e) => {
          const model = DEEPSEEK_MODELS.find(m => m.id === e.target.value);
          if (model) setSelectedModel(model);
        }}
        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 p-2"
      >
        {DEEPSEEK_MODELS.map((model) => (
          <option key={model.id} value={model.id}>
            {model.name}
          </option>
        ))}
      </select>
    </div>
  );
}