import React from 'react';
import { Mic, Send, StopCircle } from 'lucide-react';

interface InputAreaProps {
  input: string;
  setInput: (value: string) => void;
  handleSend: () => void;
  isRecording: boolean;
  startRecording: () => void;
  stopRecording: () => void;
}

export function InputArea({
  input,
  setInput,
  handleSend,
  isRecording,
  startRecording,
  stopRecording,
}: InputAreaProps) {
  return (
    <div className="border-t p-4 bg-white">
      <div className="flex items-center gap-2">
        <button
          onClick={isRecording ? stopRecording : startRecording}
          className={`p-2 rounded-full transition-colors ${
            isRecording
              ? 'bg-red-100 text-red-600 hover:bg-red-200'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
          }`}
        >
          {isRecording ? (
            <StopCircle className="w-6 h-6" />
          ) : (
            <Mic className="w-6 h-6" />
          )}
        </button>

        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask your fitness question..."
          className="flex-1 p-3 rounded-xl border focus:outline-none focus:border-purple-400 bg-gray-50"
        />

        <button
          onClick={handleSend}
          disabled={!input.trim()}
          className="p-2 rounded-full bg-purple-600 text-white hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          <Send className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}