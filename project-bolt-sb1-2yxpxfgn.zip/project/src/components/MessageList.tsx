import React from 'react';
import { ChatMessage } from '../types';
import { Dumbbell, Volume2, PauseCircle } from 'lucide-react';
import clsx from 'clsx';

interface MessageListProps {
  messages: ChatMessage[];
  isLoading: boolean;
  messagesEndRef: React.RefObject<HTMLDivElement>;
  onPlayMessage: (message: ChatMessage) => void;
  onPauseMessage: (message: ChatMessage) => void;
}

export function MessageList({ 
  messages, 
  isLoading, 
  messagesEndRef, 
  onPlayMessage,
  onPauseMessage
}: MessageListProps) {
  const formatMessage = (content: string) => {
    return content.split('\n').map((line, i) => (
      <React.Fragment key={i}>
        {line}
        {i < content.split('\n').length - 1 && <br />}
      </React.Fragment>
    ));
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-4">
      {messages.map((message, index) => (
        <div
          key={index}
          className={clsx(
            'flex items-start gap-3 animate-fade-in',
            message.role === 'user' ? 'flex-row-reverse' : ''
          )}
        >
          {message.role === 'assistant' ? (
            <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
              <Dumbbell className="w-5 h-5 text-purple-600" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
              <span className="text-blue-600 font-semibold">U</span>
            </div>
          )}
          
          <div className="flex flex-col gap-2 max-w-[80%]">
            <div
              className={clsx(
                'rounded-2xl p-4',
                message.role === 'assistant' 
                  ? 'bg-purple-50 text-gray-800' 
                  : 'bg-blue-500 text-white'
              )}
            >
              {formatMessage(message.content)}
            </div>
            {message.role === 'assistant' && (
              <button
                onClick={() => message.isPlaying ? onPauseMessage(message) : onPlayMessage(message)}
                className="self-start flex items-center gap-1 text-sm text-gray-500 hover:text-purple-600 transition-colors"
              >
                {message.isPlaying ? (
                  <>
                    <PauseCircle className="w-4 h-4" />
                    Pause message
                  </>
                ) : (
                  <>
                    <Volume2 className="w-4 h-4" />
                    Play message
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      ))}
      
      {isLoading && (
        <div className="flex items-center gap-2 text-gray-500">
          <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce" />
          <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:0.2s]" />
          <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:0.4s]" />
        </div>
      )}
      
      <div ref={messagesEndRef} />
    </div>
  );
}