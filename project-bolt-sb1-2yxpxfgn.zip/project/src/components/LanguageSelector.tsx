import React from 'react';
import { Globe2 } from 'lucide-react';
import { Language } from '../types';
import { LANGUAGES } from '../config';

interface LanguageSelectorProps {
  selectedLanguage: Language;
  setSelectedLanguage: (language: Language) => void;
}

export function LanguageSelector({ selectedLanguage, setSelectedLanguage }: LanguageSelectorProps) {
  return (
    <div className="flex items-center gap-2">
      <Globe2 className="w-5 h-5 text-gray-500" />
      <select
        value={selectedLanguage.code}
        onChange={(e) => {
          const language = LANGUAGES.find(lang => lang.code === e.target.value);
          if (language) setSelectedLanguage(language);
        }}
        className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-purple-500 focus:border-purple-500 p-2"
      >
        {LANGUAGES.map((language) => (
          <option key={language.code} value={language.code}>
            {language.name}
          </option>
        ))}
      </select>
    </div>
  );
}