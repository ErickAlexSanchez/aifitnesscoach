export const DEEPSEEK_API_KEY = 'sk-9b51bc7ba1fa4eeba171ec2ad4843541';

export const LANGUAGES: Language[] = [
  { code: 'en', name: 'English', voice: 'en-US' },
  { code: 'es', name: 'Español', voice: 'es-ES' },
  { code: 'fr', name: 'Français', voice: 'fr-FR' },
  { code: 'de', name: 'Deutsch', voice: 'de-DE' },
  { code: 'it', name: 'Italiano', voice: 'it-IT' },
  { code: 'pt', name: 'Português', voice: 'pt-PT' },
];

export const DEEPSEEK_MODELS: DeepSeekModel[] = [
  { id: 'deepseek-chat', name: 'DeepSeek Chat' },
  { id: 'deepseek-coder', name: 'DeepSeek Coder' },
];