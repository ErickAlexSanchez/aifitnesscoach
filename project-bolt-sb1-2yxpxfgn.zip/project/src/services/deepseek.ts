import axios from 'axios';
import { DEEPSEEK_API_KEY } from '../config';

const api = axios.create({
  baseURL: 'https://api.deepseek.com/v1',
  headers: {
    'Authorization': `Bearer ${DEEPSEEK_API_KEY}`,
    'Content-Type': 'application/json',
  },
});

const SYSTEM_PROMPT = `You are an expert FitnessCoach with years of experience in personal training, nutrition, and sports science. Your responses should:
- Be encouraging and motivational 🎯
- Include relevant emojis to make the content engaging
- Use line breaks to organize information clearly
- Provide specific, actionable advice
- Focus on safe and effective fitness practices
- Include both exercise and nutrition guidance when relevant
- Always maintain a professional yet friendly tone`;

export async function generateResponse(prompt: string, model: string) {
  try {
    const response = await api.post('/chat/completions', {
      model: model,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: prompt }
      ],
      temperature: 0.7,
    });

    return response.data.choices[0].message.content;
  } catch (error) {
    console.error('Error generating response:', error);
    throw new Error('Failed to generate response');
  }
}